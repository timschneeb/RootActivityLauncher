# RootActivityLauncher
Launch Hidden Activities in android via Root

Latest Version: 
https://github.com/DerekZiemba/RootActivityLauncher/releases/tag/V2.0

Based on Adam Szalkowski's Activity Launcher.  The differences are:

1.) Root access via Stericsons RootShell so that activities such as hidden menu's that you do not have permissions to open, can be opened. 

2.) Not on SourceForge...

3.) Built with Android Studio instead of Eclipse.

4.) I removed the Recent Activities feature because it didn't work. 


GooglePlay of Adam Szalkowski's version of Activity Launcher:
https://play.google.com/store/apps/details?id=de.szalkowski.activitylauncher&hl=en

Adams Sourceforge:
http://sourceforge.net/projects/activitylauncher/

Stericson's RootShell:
https://github.com/Stericson/RootShell



